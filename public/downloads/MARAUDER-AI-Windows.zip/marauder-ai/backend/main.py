from fastapi import FastAPI

app = FastAPI(
    title="MARAUDER AI"
)

@app.get("/")
def root():
    return {
        "status": "online"
    }

@app.get("/health")
def health():
    return {
        "health": "ok"
    }
