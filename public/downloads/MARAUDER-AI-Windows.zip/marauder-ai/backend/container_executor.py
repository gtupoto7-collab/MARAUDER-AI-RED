import subprocess

ALLOWED = [
    "python",
    "node",
    "npm",
    "pip"
]

def run_command(command):

    binary = command.split()[0]

    if binary not in ALLOWED:
        raise Exception("Command not allowed")

    return subprocess.run(
        command,
        shell=True,
        capture_output=True,
        text=True
    ).stdout
