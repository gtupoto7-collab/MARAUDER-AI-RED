def require_approval(action):

    return {
        "action": action,
        "approved": False,
        "status": "waiting"
    }
