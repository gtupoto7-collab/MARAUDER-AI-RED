class AIGenerator:

    def create_plan(self, prompt):

        return {
            "prompt": prompt,
            "steps": [
                "Create project",
                "Generate code",
                "Security scan",
                "Build project"
            ],
            "requires_approval": True
        }
